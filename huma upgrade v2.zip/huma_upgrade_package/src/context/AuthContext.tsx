import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  createUserWithEmailAndPassword,
  getAuth,
  deleteUser,
  GoogleAuthProvider,
  signInWithPopup,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { deleteApp, initializeApp } from 'firebase/app';
import { auth, db } from '../services/firebase';
import { AdminUser, Role } from '../types';

interface AuthContextType {
  currentUser: User | null;
  adminProfile: AdminUser | null;
  role: Role | null;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  registerAdmin: (email: string, pass: string, name: string, role: Role) => Promise<void>;
  logout: () => Promise<void>;
  canAccess: (requiredRoles: Role[]) => boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [adminProfile, setAdminProfile] = useState<AdminUser | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Clean up any old demo role persistence immediately
  useEffect(() => {
    localStorage.removeItem('huma_quick_role');
  }, []);

  // Load admin profile from Firestore when auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const adminDocRef = doc(db, 'admins', user.uid);
          const snap = await getDoc(adminDocRef);

          if (snap.exists()) {
            const data = snap.data() as AdminUser;
            setAdminProfile(data);
            setRole(data.role);
          } else if (user.email?.toLowerCase() === 'huma301123@gmail.com') {
            // Safe owner bootstrap: only the designated owner can be provisioned automatically.
            const newAdmin: AdminUser = {
              uid: user.uid,
              email: user.email || '',
              name: user.displayName || 'Owner HUMA',
              role: 'SUPER_ADMIN',
              isActive: true,
              createdAt: new Date().toISOString(),
            };
            await setDoc(adminDocRef, newAdmin, { merge: true });
            setAdminProfile(newAdmin);
            setRole('SUPER_ADMIN');
          } else {
            // Authenticated users without an admin record are not staff.
            setAdminProfile(null);
            setRole(null);
          }
        } catch (err) {
          console.warn('[HUMA] Admin profile fetch error:', err);
          // Never grant a staff role from the client when the authorization record cannot be verified.
          setAdminProfile(null);
          setRole(null);
        }
      } else {
        setAdminProfile(null);
        setRole(null);
        localStorage.removeItem('huma_quick_role');
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      console.warn('[HUMA] Google sign in error:', err?.message || err);
      throw err;
    }
  };

  const login = async (email: string, pass: string) => {
    const trimmedEmail = email.trim();
    try {
      await signInWithEmailAndPassword(auth, trimmedEmail, pass);
    } catch (err: any) {
      const code = err?.code || '';
      console.warn('[HUMA] Standard auth failed with code:', code, err?.message);

      if (
        code === 'auth/wrong-password' ||
        code === 'auth/invalid-credential' ||
        code === 'auth/invalid-login-credentials'
      ) {
        throw new Error('Kata sandi yang Anda masukkan salah. Periksa kembali sandi staff Anda.');
      }
      if (code === 'auth/invalid-email') {
        throw new Error('Format alamat email tidak valid.');
      }
      if (code === 'auth/too-many-requests') {
        throw new Error('Terlalu banyak percobaan gagal. Silakan tunggu beberapa saat lagi.');
      }
      if (code === 'auth/user-not-found') {
        throw new Error('Akun staff dengan email tersebut tidak ditemukan.');
      }

      throw new Error(err?.message || 'Login gagal. Periksa kembali email dan kata sandi staff.');
    }
  };

  const registerAdmin = async (email: string, pass: string, name: string, assignedRole: Role) => {
    // Staff provisioning is a privileged operation. Use a secondary Firebase app so
    // creating the staff Auth account does not replace the currently signed-in
    // SUPER_ADMIN session. Firestore Rules remain the final authorization boundary.
    if (role !== 'SUPER_ADMIN' && adminProfile?.role !== 'SUPER_ADMIN') {
      throw new Error('Hanya SUPER_ADMIN yang dapat menambahkan akun staff.');
    }

    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail || !pass || !name.trim()) {
      throw new Error('Email, kata sandi, dan nama staff wajib diisi.');
    }

    let secondaryApp: ReturnType<typeof initializeApp> | null = null;
    let createdUser: User | null = null;
    try {
      secondaryApp = initializeApp(auth.app.options, `huma-admin-provision-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
      const secondaryAuth = getAuth(secondaryApp);
      const cred = await createUserWithEmailAndPassword(secondaryAuth, normalizedEmail, pass);
      createdUser = cred.user;

      const newAdmin: AdminUser = {
        uid: cred.user.uid,
        email: normalizedEmail,
        name: name.trim(),
        role: assignedRole,
        isActive: true,
        createdAt: new Date().toISOString(),
      };

      // Primary admin session performs the privileged Firestore write.
      await setDoc(doc(db, 'admins', cred.user.uid), newAdmin, { merge: true });

      // Do not replace the current SUPER_ADMIN profile/session.
    } catch (err: any) {
      console.error('[HUMA] Staff provisioning failed:', err);
      if (createdUser) {
        try {
          await deleteUser(createdUser);
        } catch (rollbackError) {
          console.warn('[HUMA] Staff Auth rollback failed; orphan account may require manual cleanup:', rollbackError);
        }
      }
      throw err;
    } finally {
      if (secondaryApp) {
        try {
          await signOut(getAuth(secondaryApp));
        } catch (cleanupAuthError) {
          console.warn('[HUMA] Secondary Auth cleanup failed:', cleanupAuthError);
        }
        try {
          await deleteApp(secondaryApp);
        } catch (cleanupError) {
          console.warn('[HUMA] Secondary Firebase app cleanup failed:', cleanupError);
        }
      }
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Sign out error:', e);
    }
    localStorage.removeItem('huma_quick_role');
    setAdminProfile(null);
    setRole(null);
  };


  const canAccess = (requiredRoles: Role[]): boolean => {
    if (!role) return false;
    if (role === 'SUPER_ADMIN') return true;
    return requiredRoles.includes(role);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        adminProfile,
        role,
        isLoading,
        login,
        loginWithGoogle,
        registerAdmin,
        logout,
        canAccess,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
