HUMA Upgrade v1 — Security + Performance (feature-preserving)

Changed files:
- src/context/AuthContext.tsx
  - removes hard-coded demo credentials and quick-role session bypass
  - only the designated owner can be auto-provisioned
  - authenticated users without an admin record receive no staff role
- src/App.tsx
  - lazy-loads Admin Login Page, Admin Dashboard, POS, and Customer Rewards modal
- firestore.rules
  - keeps public storefront reads and public order creation
  - blocks self-provisioning into privileged staff roles
  - restricts catalog writes, order reads/updates/deletes, analytics, printer settings, and admin data by role
  - keeps customer/reward self-service reads/creates for compatibility with current UI

Backups should be made before replacing files.
Do NOT deploy Firestore rules until npm run build succeeds in the main repository and you have verified that all intended staff users have an admins/{uid} document with role + isActive=true.


Security hardening in v1.1:
- A non-staff authenticated user can no longer create an admins/{uid} document for themselves.
- Staff provisioning uses a secondary Firebase Auth app so the current SUPER_ADMIN session is preserved.
- POS/Admin rendering and order listeners require a verified active staff profile.
- Customer and point lookup rules intentionally remain compatible with the existing WhatsApp-based Rewards flow; migrating those reads and redemptions behind trusted backend endpoints is the next security phase.

Deployment gate:
1. Backup the existing files.
2. Replace the three patched files.
3. Run npm install and npm run build in the full project.
4. Verify existing SUPER_ADMIN/ADMIN/MANAGER/CASHIER records.
5. Test customer storefront, checkout, WhatsApp flow, Rewards, POS, Admin, receipt and staff creation.
6. Only after all checks pass, deploy hosting and Firestore rules.
