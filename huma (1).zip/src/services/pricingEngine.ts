import { Product, SelectedModifier, WholesaleRule, Promo, DeliveryArea } from '../types';

export class PricingEngine {
  /**
   * Determine the unit price of a product based on its wholesale tier rules and quantity
   */
  public static calculateUnitPrice(product: Product, quantity: number): number {
    if (!product.wholesaleEnabled || !product.wholesaleRules || product.wholesaleRules.length === 0) {
      return product.price;
    }

    // Sort rules by minQty descending to match highest tier first
    const sortedRules = [...product.wholesaleRules].sort((a, b) => b.minQty - a.minQty);
    
    for (const rule of sortedRules) {
      if (quantity >= rule.minQty) {
        if (rule.maxQty === undefined || quantity <= rule.maxQty) {
          return rule.price;
        }
      }
    }

    return product.price;
  }

  /**
   * Calculate total extra price of selected modifiers
   */
  public static calculateModifiersPrice(selectedModifiers: SelectedModifier[]): number {
    return selectedModifiers.reduce((sum, mod) => sum + (mod.item.price || 0), 0);
  }

  /**
   * Calculate line item total
   */
  public static calculateLineTotal(
    unitPrice: number,
    modifiersPrice: number,
    quantity: number
  ): number {
    return (unitPrice + modifiersPrice) * quantity;
  }

  /**
   * Validate and calculate promo discount
   */
  public static calculatePromoDiscount(
    promo: Promo | null,
    subtotal: number,
    deliveryFee: number
  ): { discount: number; effectiveDeliveryFee: number; message?: string } {
    if (!promo || !promo.isActive) {
      return { discount: 0, effectiveDeliveryFee: deliveryFee };
    }

    if (promo.minPurchase > 0 && subtotal < promo.minPurchase) {
      return {
        discount: 0,
        effectiveDeliveryFee: deliveryFee,
        message: `Minimal belanja Rp ${promo.minPurchase.toLocaleString('id-ID')} untuk promo ini.`,
      };
    }

    let discount = 0;
    let effectiveDeliveryFee = deliveryFee;

    if (promo.type === 'FREE_DELIVERY') {
      discount = deliveryFee;
      effectiveDeliveryFee = 0;
    } else if (promo.type === 'PERCENTAGE') {
      const rawDiscount = Math.round((subtotal * promo.value) / 100);
      if (promo.maxDiscount && promo.maxDiscount > 0) {
        discount = Math.min(rawDiscount, promo.maxDiscount);
      } else {
        discount = rawDiscount;
      }
    } else if (promo.type === 'FIXED') {
      discount = Math.min(promo.value, subtotal);
    }

    return {
      discount,
      effectiveDeliveryFee,
    };
  }

  /**
   * Validate cash payment amount
   */
  public static validateCashPayment(
    total: number,
    amountPaid: number
  ): { isValid: boolean; change: number; message?: string } {
    if (amountPaid < total) {
      return {
        isValid: false,
        change: 0,
        message: `Nominal pembayaran kurang Rp ${(total - amountPaid).toLocaleString('id-ID')}.`,
      };
    }

    return {
      isValid: true,
      change: amountPaid - total,
    };
  }
}
