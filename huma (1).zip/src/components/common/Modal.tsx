import React, { useEffect, useRef, useState } from 'react';
import { X, ChevronRight } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: string;
  className?: string;
  enableGestureBack?: boolean;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  maxWidth = 'max-w-lg',
  className = '',
  enableGestureBack = true,
}) => {
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          onClose();
        }
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    } else {
      document.body.style.overflow = '';
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleTouchStart = (e: React.TouchEvent) => {
    if (!enableGestureBack || e.touches.length !== 1) return;
    touchStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY,
      time: Date.now(),
    };
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStartRef.current || e.touches.length !== 1) return;
    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const deltaX = currentX - touchStartRef.current.x;
    const deltaY = currentY - touchStartRef.current.y;

    // Detect either rightward swipe or downward swipe
    if (deltaX > 0 && deltaX > Math.abs(deltaY) * 1.2) {
      // Swiping right to go back
      setDragOffset({ x: Math.min(120, deltaX * 0.6), y: 0 });
    } else if (deltaY > 0 && deltaY > Math.abs(deltaX) * 1.2) {
      // Swiping down to dismiss
      setDragOffset({ x: 0, y: Math.min(120, deltaY * 0.6) });
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStartRef.current.x;
    const deltaY = touch.clientY - touchStartRef.current.y;
    const duration = Date.now() - touchStartRef.current.time;

    const isSwipeRight = deltaX >= 75 || (deltaX >= 40 && duration < 250 && deltaX > Math.abs(deltaY));
    const isSwipeDown = deltaY >= 90 || (deltaY >= 50 && duration < 250 && deltaY > Math.abs(deltaX));

    if (isSwipeRight || isSwipeDown) {
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        try {
          navigator.vibrate(15);
        } catch {}
      }
      onClose();
    }

    touchStartRef.current = null;
    setDragOffset({ x: 0, y: 0 });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Container with Gesture Drag Support */}
      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{
          transform:
            dragOffset.x !== 0 || dragOffset.y !== 0
              ? `translate3d(${dragOffset.x}px, ${dragOffset.y}px, 0)`
              : undefined,
          transition:
            dragOffset.x === 0 && dragOffset.y === 0 ? 'transform 0.2s ease-out' : 'none',
        }}
        className={`relative w-full ${maxWidth} clay-card bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-6 my-auto shadow-2xl z-10 transition-all ${className}`}
        role="dialog"
        aria-modal="true"
      >
        {/* Mobile Drag Indicator Bar (Swipe Down / Right hint) */}
        <div className="sm:hidden flex justify-center -mt-1 mb-2.5">
          <div className="w-10 h-1 rounded-full bg-gray-200" />
        </div>

        {/* Header */}
        {(title || subtitle) && (
          <div className="flex items-start justify-between pb-3.5 mb-4 border-b border-gray-100">
            <div>
              {title && <h3 className="font-heading font-extrabold text-lg sm:text-xl text-[#2E1A47]">{title}</h3>}
              {subtitle && <p className="text-xs text-gray-500 mt-0.5">{subtitle}</p>}
            </div>
            <button
              onClick={onClose}
              className="p-1.5 -mr-1.5 -mt-1 rounded-full text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors cursor-pointer"
              aria-label="Tutup"
              title="Tutup (Bisa geser ke kanan untuk kembali)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* Content */}
        <div>{children}</div>
      </div>
    </div>
  );
};
