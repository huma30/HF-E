import React, { useState, useId } from 'react';
import { Modal } from '../common/Modal';
import { useCart } from '../../context/CartContext';
import { DeliveryArea, PaymentMethod, ServiceType, Order, StoreSettings } from '../../types';
import { FirestoreService } from '../../services/firestoreService';
import { PricingEngine } from '../../services/pricingEngine';
import { soundService } from '../../services/audioNotification';
import { WhatsAppService } from '../../services/whatsappService';
import {
  MapPin,
  Clock,
  Phone,
  User,
  Banknote,
  QrCode,
  CreditCard,
  AlertCircle,
  Loader2,
  CheckCircle2,
  MessageCircle,
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  deliveryAreas: DeliveryArea[];
  settings: StoreSettings | null;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  deliveryAreas,
  settings,
  onOrderSuccess,
}) => {
  const {
    items,
    subtotal,
    discount,
    appliedPromo,
    clearCart,
    serviceType,
    setServiceType,
    selectedDeliveryArea,
    setDeliveryArea,
  } = useCart();

  const [customerName, setCustomerName] = useState('');
  const [customerWhatsapp, setCustomerWhatsapp] = useState('');
  const [address, setAddress] = useState('');
  const [orderNotes, setOrderNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CASH');
  const [amountPaidInput, setAmountPaidInput] = useState<string>('');

  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Idempotency key generated per modal open
  const formSessionKey = useId();
  const [idempotencyKey] = useState(() => `web_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`);

  // Active delivery areas
  const activeAreas = deliveryAreas.filter((a) => a.isActive);

  // Delivery fee
  const deliveryFee =
    serviceType === 'DELIVERY' && selectedDeliveryArea ? selectedDeliveryArea.deliveryFee : 0;

  // Total
  const total = Math.max(0, subtotal - discount + deliveryFee);

  // Cash calculation
  const parsedAmountPaid =
    paymentMethod === 'CASH' || paymentMethod === 'COD'
      ? amountPaidInput.trim() === ''
        ? total
        : parseInt(amountPaidInput.replace(/\D/g, ''), 10) || 0
      : total;

  const change = Math.max(0, parsedAmountPaid - total);

  // Quick cash options
  const quickCashOptions = [total, 20000, 50000, 100000].filter((val) => val >= total);
  const uniqueQuickCash = Array.from(new Set(quickCashOptions)).sort((a, b) => a - b);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isProcessing) return; // Anti-double order guard

    setErrorMessage(null);

    // 1. Validate customer name
    if (!customerName.trim()) {
      setErrorMessage('Mohon masukkan nama pemesan.');
      return;
    }

    // 2. Validate delivery details if delivery
    if (serviceType === 'DELIVERY') {
      if (!selectedDeliveryArea) {
        setErrorMessage('Mohon pilih area pengantaran.');
        return;
      }
      if (subtotal < selectedDeliveryArea.minOrderAmount) {
        setErrorMessage(
          `Minimal order untuk area ${selectedDeliveryArea.name} adalah Rp ${selectedDeliveryArea.minOrderAmount.toLocaleString('id-ID')}.`
        );
        return;
      }
      if (!address.trim()) {
        setErrorMessage('Mohon cantumkan alamat pengantaran lengkap.');
        return;
      }
    }

    // 3. Validate cash payment amount
    if ((paymentMethod === 'CASH' || paymentMethod === 'COD') && amountPaidInput.trim() !== '') {
      const cashCheck = PricingEngine.validateCashPayment(total, parsedAmountPaid);
      if (!cashCheck.isValid) {
        setErrorMessage(cashCheck.message || 'Nominal uang yang dibayarkan kurang.');
        return;
      }
    }

    // 4. Submit Order
    try {
      setIsProcessing(true);

      const customerData: Order['customer'] = {
        name: customerName.trim(),
        whatsapp: customerWhatsapp.trim() || '-',
      };
      if (serviceType === 'DELIVERY' && address.trim()) {
        customerData.address = address.trim();
      }
      if (orderNotes.trim()) {
        customerData.notes = orderNotes.trim();
      }

      const orderPayload: Omit<Order, 'id' | 'orderNumber' | 'createdAt'> = {
        source: 'WEB',
        status: 'PENDING',
        customer: customerData,
        serviceType,
        items,
        subtotal,
        discount,
        deliveryFee,
        total,
        paymentMethod,
        amountPaid: parsedAmountPaid || total,
        change: change || 0,
        idempotencyKey,
      };

      if (serviceType === 'DELIVERY') {
        if (selectedDeliveryArea?.id) orderPayload.deliveryAreaId = selectedDeliveryArea.id;
        if (selectedDeliveryArea?.name) orderPayload.deliveryAreaName = selectedDeliveryArea.name;
      }
      if (appliedPromo?.code) {
        orderPayload.promoCode = appliedPromo.code;
      }

      const createdOrder = await FirestoreService.createOrder(orderPayload);
      soundService.playNewOrderChime();

      // Direct redirect ke WhatsApp Admin dengan rincian order dinamis
      const cleanStorePhone = (settings?.whatsapp || '085878775527').replace(/^0/, '62').replace(/\D/g, '');
      const waUrl = WhatsAppService.getWhatsAppUrl(createdOrder, cleanStorePhone);

      try {
        const waWin = window.open(waUrl, '_blank');
        if (!waWin || waWin.closed || typeof waWin.closed === 'undefined') {
          window.location.href = waUrl;
        }
      } catch {
        window.location.href = waUrl;
      }

      clearCart();
      onClose();
      onOrderSuccess(createdOrder);
    } catch (err: any) {
      console.error('Order creation error:', err);
      setErrorMessage(
        err?.message || 'Gagal memproses pesanan. Silakan coba sesaat lagi.'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => !isProcessing && onClose()}
      title="Konfirmasi & Pembayaran"
      subtitle="Periksa kembali detail pesanan Anda"
      maxWidth="max-w-lg"
    >
      <form onSubmit={handleSubmitOrder} className="space-y-4 max-h-[78vh] overflow-y-auto pr-1">
        {/* Service Type Selection (Delivery vs Takeaway) */}
        <div>
          <label className="block text-xs font-bold text-[#2E1A47] mb-1.5">
            Layanan Pesanan:
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setServiceType('DELIVERY')}
              className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                serviceType === 'DELIVERY'
                  ? 'bg-[#2E1A47] text-white border-[#2E1A47] shadow-sm'
                  : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
            >
              <span className="text-base">🛵</span>
              <span>Antar ke Rumah (Delivery)</span>
            </button>

            <button
              type="button"
              onClick={() => setServiceType('TAKEAWAY')}
              className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                serviceType === 'TAKEAWAY'
                  ? 'bg-[#2E1A47] text-white border-[#2E1A47] shadow-sm'
                  : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
            >
              <span className="text-base">🛍️</span>
              <span>Ambil Sendiri (Takeaway)</span>
            </button>
          </div>
        </div>

        {/* Customer Information */}
        <div className="bg-gray-50/80 p-3.5 rounded-2xl border border-gray-100 space-y-3">
          <h4 className="text-xs font-extrabold text-[#2E1A47] uppercase tracking-wider">
            Informasi Pemesan
          </h4>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Nama Anda <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Cth: Budi / Siti"
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl bg-white border border-gray-200 focus:outline-hidden focus:ring-2 focus:ring-[#FF4500]/30"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Nomor WhatsApp <span className="text-gray-400 font-normal">(Opsional)</span>
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="tel"
                value={customerWhatsapp}
                onChange={(e) => setCustomerWhatsapp(e.target.value)}
                placeholder="08xxxxxxxxxx (bisa dikosongkan)"
                className="w-full text-xs pl-9 pr-3 py-2 rounded-xl bg-white border border-gray-200 focus:outline-hidden focus:ring-2 focus:ring-[#FF4500]/30"
              />
            </div>
            <p className="text-[10px] text-gray-400 mt-0.5">
              Jika kosong, otomatis tercatat "-" di sistem.
            </p>
          </div>
        </div>

        {/* Delivery Area & Address (Only if Delivery) */}
        {serviceType === 'DELIVERY' && (
          <div className="bg-gray-50/80 p-3.5 rounded-2xl border border-gray-100 space-y-3">
            <h4 className="text-xs font-extrabold text-[#2E1A47] uppercase tracking-wider flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#FF4500]" />
              Detail Alamat Pengantaran
            </h4>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Pilih Area Pengantaran <span className="text-rose-500">*</span>
              </label>
              <div className="space-y-1.5">
                {activeAreas.map((area) => {
                  const isSelected = selectedDeliveryArea?.id === area.id;
                  return (
                    <button
                      key={area.id}
                      type="button"
                      onClick={() => setDeliveryArea(area)}
                      className={`w-full p-2.5 rounded-xl text-left border text-xs transition-all ${
                        isSelected
                          ? 'bg-white border-2 border-[#2E1A47] shadow-xs'
                          : 'bg-white/70 border-gray-200 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#2E1A47]">{area.name}</span>
                        <span className="font-extrabold text-[#FF4500]">
                          {area.deliveryFee === 0 ? 'Gratis Ongkir' : `+Rp ${area.deliveryFee.toLocaleString('id-ID')}`}
                        </span>
                      </div>
                      <div className="text-[11px] text-gray-500 flex items-center gap-2 mt-0.5">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" /> ±{area.estimatedDeliveryMinutes} mnt
                        </span>
                        <span>• Min. Rp {area.minOrderAmount.toLocaleString('id-ID')}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Alamat Lengkap / Blok Rumah <span className="text-rose-500">*</span>
              </label>
              <textarea
                required
                rows={2}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Cth: Perum Gina Blok A No. 5 (Pagar hitam, cat krem)"
                className="w-full text-xs p-2.5 rounded-xl bg-white border border-gray-200 focus:outline-hidden focus:ring-2 focus:ring-[#FF4500]/30"
              />
            </div>
          </div>
        )}

        {/* Order Notes */}
        <div>
          <label className="block text-xs font-semibold text-gray-700 mb-1">
            Catatan Tambahan untuk Dapur (Opsional):
          </label>
          <input
            type="text"
            value={orderNotes}
            onChange={(e) => setOrderNotes(e.target.value)}
            placeholder="Cth: Sambal dipisah ya min..."
            className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200 focus:outline-hidden"
          />
        </div>

        {/* Payment Method */}
        <div className="bg-gray-50/80 p-3.5 rounded-2xl border border-gray-100 space-y-3">
          <h4 className="text-xs font-extrabold text-[#2E1A47] uppercase tracking-wider">
            Metode Pembayaran
          </h4>

          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMethod('CASH')}
              className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                paymentMethod === 'CASH'
                  ? 'bg-[#2E1A47] text-white border-[#2E1A47] shadow-xs'
                  : 'bg-white text-gray-700 border-gray-200'
              }`}
            >
              <Banknote className="w-4 h-4 text-emerald-400" />
              <span>Tunai / COD</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('QRIS')}
              className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                paymentMethod === 'QRIS'
                  ? 'bg-[#2E1A47] text-white border-[#2E1A47] shadow-xs'
                  : 'bg-white text-gray-700 border-gray-200'
              }`}
            >
              <QrCode className="w-4 h-4 text-blue-400" />
              <span>QRIS</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('BANK_TRANSFER')}
              className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                paymentMethod === 'BANK_TRANSFER'
                  ? 'bg-[#2E1A47] text-white border-[#2E1A47] shadow-xs'
                  : 'bg-white text-gray-700 border-gray-200'
              }`}
            >
              <CreditCard className="w-4 h-4 text-purple-400" />
              <span>Transfer</span>
            </button>
          </div>

          {/* Cash Payment: Amount Paid & Change Calculation */}
          {(paymentMethod === 'CASH' || paymentMethod === 'COD') && (
            <div className="pt-2 border-t border-gray-200/60 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-700">
                  Uang yang Disiapkan:
                </label>
                <span className="text-[11px] text-gray-500">
                  Total: Rp {total.toLocaleString('id-ID')}
                </span>
              </div>

              <input
                type="text"
                value={amountPaidInput}
                onChange={(e) => setAmountPaidInput(e.target.value)}
                placeholder={`Uang Pas (Rp ${total.toLocaleString('id-ID')})`}
                className="w-full text-xs px-3 py-2 rounded-xl bg-white border border-gray-200 focus:outline-hidden focus:ring-2 focus:ring-[#FF4500]/30 font-semibold"
              />

              {/* Quick Cash Buttons */}
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setAmountPaidInput(String(total))}
                  className="px-2.5 py-1 rounded-lg bg-white border border-gray-200 text-[11px] font-bold text-gray-700 hover:bg-gray-100"
                >
                  Uang Pas
                </button>
                {uniqueQuickCash.map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAmountPaidInput(String(val))}
                    className="px-2.5 py-1 rounded-lg bg-white border border-gray-200 text-[11px] font-bold text-gray-700 hover:bg-gray-100"
                  >
                    Rp {val.toLocaleString('id-ID')}
                  </button>
                ))}
              </div>

              {/* Instant Change Indicator */}
              <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between text-xs text-emerald-800 font-bold">
                <span>Kembalian:</span>
                <span>Rp {change.toLocaleString('id-ID')}</span>
              </div>
            </div>
          )}

          {/* QRIS / Bank Transfer helper text */}
          {paymentMethod === 'QRIS' && (
            <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
              <p className="font-bold">📱 Bayar via QRIS</p>
              <p className="text-[11px] text-blue-800 mt-0.5">
                Scan QRIS HUMA saat konfirmasi WhatsApp atau saat pesanan tiba.
              </p>
            </div>
          )}
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-700 text-xs font-semibold">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Submit Order Button with Anti-Double Click Protection */}
        <div className="pt-2 border-t border-gray-100">
          <button
            id="btn-submit-order"
            type="submit"
            disabled={isProcessing}
            className="w-full clay-button-primary py-3 px-4 flex items-center justify-center gap-2 text-sm font-bold shadow-lg disabled:opacity-60"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Memproses Pesanan...</span>
              </>
            ) : (
              <>
                <MessageCircle className="w-4 h-4 text-emerald-300" />
                <span>Pesan Sekarang via WhatsApp • Rp {total.toLocaleString('id-ID')}</span>
              </>
            )}
          </button>
          <p className="text-[10px] text-gray-400 text-center mt-1.5">
            Pesanan otomatis tersimpan di sistem toko & terhubung ke WhatsApp Admin
          </p>
        </div>
      </form>
    </Modal>
  );
};
