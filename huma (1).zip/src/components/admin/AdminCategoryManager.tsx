import React, { useState } from 'react';
import { Category } from '../../types';
import { FirestoreService } from '../../services/firestoreService';
import { errorService } from '../../services/errorService';
import { Modal } from '../common/Modal';
import { Plus, Edit2, Trash2, Tag, Check, X, Loader2 } from 'lucide-react';

interface AdminCategoryManagerProps {
  categories: Category[];
  onRefresh: () => void;
}

export const AdminCategoryManager: React.FC<AdminCategoryManagerProps> = ({
  categories,
  onRefresh,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [icon, setIcon] = useState('🍲');
  const [sortOrder, setSortOrder] = useState(1);
  const [isActive, setIsActive] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleOpenNew = () => {
    setEditingCategory(null);
    setName('');
    setSlug('');
    setIcon('🍲');
    setSortOrder(categories.length + 1);
    setIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: Category) => {
    setEditingCategory(c);
    setName(c.name);
    setSlug(c.slug);
    setIcon(c.icon || c.iconName || '🍲');
    setSortOrder(c.sortOrder);
    setIsActive(c.isActive);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Nama kategori wajib diisi.');
      return;
    }

    setIsSubmitting(true);
    try {
      const generatedSlug = slug.trim() || name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      const payload: Omit<Category, 'id'> = {
        name: name.trim(),
        slug: generatedSlug,
        icon: icon.trim() || '🍲',
        iconName: icon.trim() || '🍲',
        sortOrder: Number(sortOrder) || 1,
        isActive,
      };

      if (editingCategory) {
        await FirestoreService.updateCategory(editingCategory.id, payload);
      } else {
        await FirestoreService.createCategory(payload);
      }

      setIsModalOpen(false);
      onRefresh();
    } catch (err: any) {
      errorService.capture(err, { action: 'saveCategory', name });
      alert(err?.message || 'Gagal menyimpan kategori.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (c: Category) => {
    if (confirm(`Hapus kategori "${c.name}"?`)) {
      try {
        await FirestoreService.deleteCategory(c.id);
        onRefresh();
      } catch (err) {
        alert('Gagal menghapus kategori.');
      }
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading font-extrabold text-xl text-[#2E1A47]">
            Manajemen Kategori
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Atur urutan dan pengelompokan menu di etalase pelanggan dan kasir
          </p>
        </div>

        <button
          onClick={handleOpenNew}
          className="clay-button-primary py-2 px-3.5 text-xs font-bold flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Kategori</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {categories.map((c) => (
          <div
            key={c.id}
            className="clay-card p-4 flex items-center justify-between gap-3"
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center">
                {c.icon || '🍲'}
              </span>
              <div>
                <h4 className="font-heading font-bold text-sm text-[#2E1A47]">{c.name}</h4>
                <p className="text-[11px] text-gray-400">
                  Urutan ke-{c.sortOrder} • {c.isActive ? 'Aktif' : 'Nonaktif'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => handleOpenEdit(c)}
                className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-[#2E1A47]"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete(c)}
                className="p-1.5 rounded-lg text-gray-400 hover:bg-rose-50 hover:text-rose-600"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCategory ? 'Edit Kategori' : 'Tambah Kategori'}
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Nama Kategori:</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200 focus:outline-hidden"
              placeholder="Cth: Seblak Prasmanan"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Icon / Emoji:</label>
              <input
                type="text"
                value={icon}
                onChange={(e) => setIcon(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200 text-center text-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Nomor Urut:</label>
              <input
                type="number"
                value={sortOrder}
                onChange={(e) => setSortOrder(Number(e.target.value) || 1)}
                className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="rounded-sm text-[#2E1A47]"
            />
            <span>Aktifkan Kategori</span>
          </label>

          <div className="pt-3 border-t border-gray-100 flex justify-end gap-2">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-gray-600 hover:bg-gray-100 disabled:opacity-50"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="clay-button-primary py-2 px-5 text-xs font-bold flex items-center gap-2 disabled:opacity-60"
            >
              {isSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              <span>{isSubmitting ? 'Menyimpan...' : 'Simpan Kategori'}</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
