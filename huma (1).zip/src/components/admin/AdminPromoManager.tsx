import React, { useState } from 'react';
import { Promo, PromoType } from '../../types';
import { FirestoreService } from '../../services/firestoreService';
import { errorService } from '../../services/errorService';
import { Modal } from '../common/Modal';
import { Plus, Edit2, Trash2, Tag, Percent, Sparkles, Check, X, Loader2 } from 'lucide-react';

interface AdminPromoManagerProps {
  promos: Promo[];
  onRefresh: () => void;
}

export const AdminPromoManager: React.FC<AdminPromoManagerProps> = ({ promos, onRefresh }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPromo, setEditingPromo] = useState<Promo | null>(null);

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [discountType, setDiscountType] = useState<PromoType>('FIXED');
  const [discountValue, setDiscountValue] = useState<number>(5000);
  const [minOrderAmount, setMinOrderAmount] = useState<number>(30000);
  const [maxDiscountAmount, setMaxDiscountAmount] = useState<number>(10000);
  const [isActive, setIsActive] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleOpenNew = () => {
    setEditingPromo(null);
    setCode('PROMO' + Math.floor(100 + Math.random() * 900));
    setName('Promo Spesial HUMA');
    setDiscountType('FIXED');
    setDiscountValue(5000);
    setMinOrderAmount(30000);
    setMaxDiscountAmount(10000);
    setIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (p: Promo) => {
    setEditingPromo(p);
    setCode(p.code);
    setName(p.name);
    setDiscountType(p.discountType || p.type || 'FIXED');
    setDiscountValue(p.discountValue ?? p.value ?? 0);
    setMinOrderAmount(p.minOrderAmount ?? p.minPurchase ?? 0);
    setMaxDiscountAmount(p.maxDiscountAmount ?? p.maxDiscount ?? 0);
    setIsActive(p.isActive);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCode = code.trim().toUpperCase().replace(/\s+/g, '');
    if (!cleanCode) {
      alert('Kode promo wajib diisi.');
      return;
    }
    if (!name.trim()) {
      alert('Nama promo wajib diisi.');
      return;
    }
    if (Number(discountValue) <= 0) {
      alert('Nilai diskon promo harus lebih dari 0.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: Omit<Promo, 'id'> = {
        code: cleanCode,
        name: name.trim(),
        type: discountType,
        value: Number(discountValue),
        minPurchase: Number(minOrderAmount) || 0,
        maxDiscount: discountType === 'PERCENTAGE' ? Number(maxDiscountAmount) || 0 : 0,
        discountType,
        discountValue: Number(discountValue),
        minOrderAmount: Number(minOrderAmount) || 0,
        maxDiscountAmount: discountType === 'PERCENTAGE' ? Number(maxDiscountAmount) || 0 : 0,
        usedCount: editingPromo ? editingPromo.usedCount : 0,
        isActive,
      };

      if (editingPromo) {
        await FirestoreService.updatePromo(editingPromo.id, payload);
      } else {
        await FirestoreService.createPromo(payload);
      }

      setIsModalOpen(false);
      onRefresh();
    } catch (err: any) {
      errorService.capture(err, { action: 'savePromo', code: cleanCode });
      alert(err?.message || 'Gagal menyimpan promo.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (p: Promo) => {
    if (confirm(`Hapus kode promo "${p.code}"?`)) {
      try {
        await FirestoreService.deletePromo(p.id);
        onRefresh();
      } catch (err) {
        alert('Gagal menghapus promo.');
      }
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading font-extrabold text-xl text-[#2E1A47]">
            Voucher & Diskon Promo
          </h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Buat kode kupon diskon nominal, persentase, atau gratis ongkir
          </p>
        </div>

        <button
          onClick={handleOpenNew}
          className="clay-button-primary py-2 px-3.5 text-xs font-bold flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Buat Kode Promo</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {promos.map((p) => (
          <div key={p.id} className="clay-card p-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="font-mono font-extrabold text-sm text-[#FF4500] bg-orange-50 px-2.5 py-1 rounded-lg border border-orange-200">
                  {p.code}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    p.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-gray-100 text-gray-500'
                  }`}
                >
                  {p.isActive ? 'Aktif' : 'Nonaktif'}
                </span>
              </div>

              <h4 className="font-heading font-bold text-sm text-[#2E1A47] mt-2.5">{p.name}</h4>
              <p className="text-xs text-gray-600 mt-1">
                Potongan:{' '}
                <strong className="text-gray-900">
                  {(p.discountType || p.type) === 'PERCENTAGE'
                    ? `${p.discountValue ?? p.value}%`
                    : (p.discountType || p.type) === 'FREE_DELIVERY'
                    ? 'Gratis Ongkir'
                    : `Rp ${(p.discountValue ?? p.value ?? 0).toLocaleString('id-ID')}`}
                </strong>
              </p>
              <p className="text-[11px] text-gray-400 mt-0.5">
                Min. Belanja: Rp {(p.minOrderAmount ?? p.minPurchase ?? 0).toLocaleString('id-ID')}
              </p>
            </div>

            <div className="mt-3 pt-2 border-t border-gray-100 flex justify-end gap-1.5">
              <button
                onClick={() => handleOpenEdit(p)}
                className="p-1.5 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-[#2E1A47]"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete(p)}
                className="p-1.5 rounded-lg text-gray-400 hover:bg-rose-50 hover:text-rose-600"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingPromo ? 'Edit Kode Promo' : 'Buat Kode Promo'}
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Kode Voucher:</label>
            <input
              type="text"
              required
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="Cth: HUMAJOS"
              className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200 uppercase font-mono font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Nama Promo:</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Tipe Diskon:</label>
              <select
                value={discountType}
                onChange={(e) => setDiscountType(e.target.value as PromoType)}
                className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200 font-semibold"
              >
                <option value="FIXED">Nominal Tetap (Rp)</option>
                <option value="PERCENTAGE">Persentase (%)</option>
                <option value="FREE_DELIVERY">Gratis Ongkir</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">
                Nilai Diskon:
              </label>
              <input
                type="number"
                value={discountValue}
                onChange={(e) => setDiscountValue(Number(e.target.value) || 0)}
                className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200 font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">Minimal Belanja (Rp):</label>
            <input
              type="number"
              value={minOrderAmount}
              onChange={(e) => setMinOrderAmount(Number(e.target.value) || 0)}
              className="w-full text-xs px-3 py-2 rounded-xl bg-gray-50 border border-gray-200"
            />
          </div>

          <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="rounded-sm text-[#2E1A47]"
            />
            <span>Promo Aktif</span>
          </label>

          <div className="pt-3 border-t border-gray-100 flex justify-end gap-2">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-gray-600 hover:bg-gray-100 disabled:opacity-50"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="clay-button-primary py-2 px-5 text-xs font-bold flex items-center gap-2 disabled:opacity-60"
            >
              {isSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
              <span>{isSubmitting ? 'Menyimpan...' : 'Simpan Promo'}</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
