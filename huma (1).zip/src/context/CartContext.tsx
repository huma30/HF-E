import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, Product, SelectedModifier, Promo, DeliveryArea, ServiceType } from '../types';
import { PricingEngine } from '../services/pricingEngine';

interface CartContextType {
  items: CartItem[];
  itemCount: number;
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  appliedPromo: Promo | null;
  selectedDeliveryArea: DeliveryArea | null;
  serviceType: ServiceType;
  addItem: (
    product: Product,
    quantity: number,
    selectedModifiers: SelectedModifier[],
    notes?: string
  ) => void;
  updateItemQuantity: (cartItemId: string, quantity: number, allProducts: Product[]) => void;
  removeItem: (cartItemId: string) => void;
  updateItemNotes: (cartItemId: string, notes: string) => void;
  clearCart: () => void;
  applyPromo: (promo: Promo | null) => { success: boolean; message?: string };
  removePromo: () => void;
  setDeliveryArea: (area: DeliveryArea | null) => void;
  setServiceType: (type: ServiceType) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = 'huma_cart_v3';

export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedPromo, setAppliedPromo] = useState<Promo | null>(null);
  const [selectedDeliveryArea, setSelectedDeliveryArea] = useState<DeliveryArea | null>(null);
  const [serviceType, setServiceType] = useState<ServiceType>('DELIVERY');

  // Persist cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.warn('Unable to persist cart locally', e);
    }
  }, [items]);

  // Derived calculations
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + item.lineTotal, 0);

  const rawDeliveryFee = serviceType === 'DELIVERY' && selectedDeliveryArea ? selectedDeliveryArea.deliveryFee : 0;
  
  const { discount, effectiveDeliveryFee } = PricingEngine.calculatePromoDiscount(
    appliedPromo,
    subtotal,
    rawDeliveryFee
  );

  const total = Math.max(0, subtotal - discount + effectiveDeliveryFee);

  const addItem = (
    product: Product,
    quantity: number,
    selectedModifiers: SelectedModifier[],
    notes?: string
  ) => {
    const safeNotes = typeof notes === 'string' ? notes.trim() : '';

    // Generate a signature for identical modifiers to stack items
    const modSignature = (selectedModifiers || [])
      .map((m) => `${m.groupId}:${m.item?.id || ''}`)
      .sort()
      .join('|');
    
    const cartItemId = `${product.id}_${modSignature}_${safeNotes}`;
    const modifiersPrice = PricingEngine.calculateModifiersPrice(selectedModifiers || []);

    setItems((prevItems) => {
      const existingIndex = prevItems.findIndex((item) => item.cartItemId === cartItemId);
      if (existingIndex > -1) {
        const existing = prevItems[existingIndex];
        const newQty = existing.quantity + quantity;
        const unitPrice = PricingEngine.calculateUnitPrice(product, newQty);
        const lineTotal = PricingEngine.calculateLineTotal(unitPrice, modifiersPrice, newQty);

        const updated = [...prevItems];
        updated[existingIndex] = {
          ...existing,
          quantity: newQty,
          unitPrice,
          lineTotal,
        };
        return updated;
      } else {
        const unitPrice = PricingEngine.calculateUnitPrice(product, quantity);
        const lineTotal = PricingEngine.calculateLineTotal(unitPrice, modifiersPrice, quantity);

        const newItem: CartItem = {
          cartItemId,
          productId: product.id,
          productName: product.name,
          productImage: product.imageUrl,
          basePrice: product.price,
          unitPrice,
          quantity,
          selectedModifiers: selectedModifiers || [],
          modifiersPrice,
          lineTotal,
          notes: safeNotes || undefined,
        };
        return [...prevItems, newItem];
      }
    });
  };

  const updateItemQuantity = (cartItemId: string, newQty: number, allProducts: Product[]) => {
    if (newQty <= 0) {
      removeItem(cartItemId);
      return;
    }

    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.cartItemId !== cartItemId) return item;
        const matchedProduct = allProducts.find((p) => p.id === item.productId);
        const unitPrice = matchedProduct
          ? PricingEngine.calculateUnitPrice(matchedProduct, newQty)
          : item.unitPrice;
        const lineTotal = PricingEngine.calculateLineTotal(unitPrice, item.modifiersPrice, newQty);
        return {
          ...item,
          quantity: newQty,
          unitPrice,
          lineTotal,
        };
      })
    );
  };

  const removeItem = (cartItemId: string) => {
    setItems((prev) => prev.filter((item) => item.cartItemId !== cartItemId));
  };

  const updateItemNotes = (cartItemId: string, notes: string) => {
    const safeNotes = typeof notes === 'string' ? notes.trim() : '';
    setItems((prev) =>
      prev.map((item) => (item.cartItemId === cartItemId ? { ...item, notes: safeNotes } : item))
    );
  };

  const clearCart = () => {
    setItems([]);
    setAppliedPromo(null);
  };

  const applyPromo = (promo: Promo | null) => {
    if (!promo) {
      setAppliedPromo(null);
      return { success: true };
    }
    const result = PricingEngine.calculatePromoDiscount(promo, subtotal, rawDeliveryFee);
    if (result.message) {
      return { success: false, message: result.message };
    }
    setAppliedPromo(promo);
    return { success: true };
  };

  const removePromo = () => {
    setAppliedPromo(null);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount,
        subtotal,
        discount,
        deliveryFee: effectiveDeliveryFee,
        total,
        appliedPromo,
        selectedDeliveryArea,
        serviceType,
        addItem,
        updateItemQuantity,
        removeItem,
        updateItemNotes,
        clearCart,
        applyPromo,
        removePromo,
        setDeliveryArea: setSelectedDeliveryArea,
        setServiceType,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
